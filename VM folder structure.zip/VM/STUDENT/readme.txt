FOLDER: STUDENT
Placeholder for student training files. This folder has various subfolders:
- Buildingblocks
  Automation buildingblocks to import into Ivanti Automation.
- Documentation
  Student manuals, administration guides, links to documentation.
- Training Files
  Files needed for training class.

MarcelVenema.com