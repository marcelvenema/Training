FOLDER: VMNAME.DATE
Placeholder for each virtual machine. I use VMNAME.INSTALLATIONDATE as a naming convention, for example DC1.20190101 or XA2.20190106
MarcelVenema.com